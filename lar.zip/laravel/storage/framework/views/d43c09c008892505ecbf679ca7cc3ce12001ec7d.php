<?php $__env->startSection('script'); ?>
        <script src="js/Personal.js"></script>
<?php $__env->stopSection(); ?>
        <?php if( isset($add)): ?>
            <?php if($add==true): ?>
                <?php echo "<h2>Добавление успешно!</h2>"; ?>

            <?php else: ?> 
                <?php echo "<h2>Произошла ошибка при добавлении!</h2>"; ?>

            <?php endif; ?>
        <?php endif; ?>

      <?php $__env->startSection('inform'); ?>
        <div class="add">
            <div class="btn">
       <a href="#" > Добавить сотрудника</a>
        <div class="bg"></div>
       </div>
          <?php echo Form::open(['action' => ['AddControl@add', $login],'method' => 'get','class' => 'add_form']); ?>

              <h4>Форма добавления</h2>
            <div class="Labels">
                <label for="Login"> Логин:</label>
                <label for="Pass"> Пароль:</label>
                <label for="Name"> Имя:</label>
                <label for="Surname"> Фамилия:</label>
                <label for="admin"> Администратор:</label>
            </div>
            <div class="Inputs">
                <input type="text"  name="login" placeholder="Введите логин" /> <br />
                <input type="text"  name="pass" placeholder="Введите пароль" /><br />
                <input type="text"  name="Name" placeholder="Введите имя " /><br />
                <input type="text"  name="Surname" placeholder="Введите фамилию" /><br />
                <input type="checkbox" name="admin"  /><br />
            </div>
            <?php echo Form::submit('Добавить'); ?>

            <?php echo Form::close(); ?>

        </div>
        <div class="Statictic_table">
          <div class="btn">
         <a href="#">Показать статистику</a>
        <div class="bg"></div>
       </div>
            <table id='Statictic'>
                 <?php include('date.php'); ?>
                <tr> 
                <th>Логин</th>
                <th>Фамилия</th>
                <th>Имя</th>
                <th>Дата</th>
                <th>Пришел</th>
                <th>Ушел</th>
                <th>Время работы</th>
                </tr>
           
                <?php foreach($users as $row): ?>
                <tr>
            <td><?php echo e($row->login); ?></td>
            <td><?php echo e($row->Surname); ?></td>        
            <td><?php echo e($row->Name); ?></td>
            <td> <?php echo e(@date("d", strtotime($row->Start))."  ".$month[@date("n", strtotime($row->Start))]." ".@date("Y", strtotime($row->Start))); ?> </td>
            <td><?php echo e(@date("G:i", strtotime($row->Start))); ?> </td>
            <td><?php echo e(@date("G:i", strtotime($row->Finish))); ?> </td>
            <td>
                <?php if( @date("i", strtotime($row->Finish)) >= @date("i", strtotime($row->Finish)) ): ?> 
                    <?php echo e((@date("G", strtotime($row->Finish))- @date("G", strtotime($row->Start)))." час(а) "
                .(@date("i", strtotime($row->Finish)) - @date("i", strtotime($row->Start)))." минут(а)"); ?>

                <?php else: ?>
                     <?php echo e((@date("G", strtotime($row->Finish))-1- @date("G", strtotime($row->Start))).":"
                .(60+@date("i", strtotime($row->Finish)) - @date("i", strtotime($row->Start)))); ?>

                <?php endif; ?>
            </td>
                    </tr>
                <?php endforeach; ?>
            </table>
       <?php echo $users->appends(['login' => $login, 'pass' => $pass])->links(); ?>

        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cabinet', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>