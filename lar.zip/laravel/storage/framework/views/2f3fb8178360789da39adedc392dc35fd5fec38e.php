<!DOCTYPE html>
<html lang="en-GB">
  <head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
  </head>
  <body>
    <div class="header">
      <ul>
        <?php $__env->startSection('navigation'); ?>
          <li><a href="#">Главная</a></li>
          <li><a href="#">Блог</a></li>
      </ul>
    </div>

    <?php echo $__env->yieldContent('content'); ?>

  </body>
</html>