<?php $__env->startSection('cont'); ?>
<div class="container">
               <div class="btn">
         <a href="#" >Старт</a>
        <div class="bg"></div>
            </div>
           <div class="Timer_form">
            <?php echo Form::open(['action' => ['HoursController@add', $login],'method' => 'post','class' => 'Timer']); ?>

                <input type="text"  name="hours"  readonly />
                <input type="text"  name="minutes" readonly /><br />
             <?php echo Form::submit('Всем пока'); ?>

            <?php echo Form::close(); ?>

</div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('personal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>