<?php $__env->startSection('content'); ?>
<html lang="ru-RU">
    <head>
    <meta charset="UTF-8">
    <title>Личный кабинет</title>
        <style>
            body{
                text-align: center;
                font-size: 24px;
            }
            .container{
                margin-top: 5%;
            }
            .form_login{
                float: left;
            }
        </style>
        <script src="jquery-2.1.4.min.js"></script>
        <script>
            function GetDateTime(){
                var date = new Date();
                return (date.getYear()+1900)+"-"+(date.getMonth()+1)+"-"+date.getDate()+" "+ date.getHours() + ":" + date.getMinutes()+":00";
            };
            $(document).ready(function(){
                start=true;
                var inter,minets,date_start,send;
                $("#Work_button").click(function(){
                    start=!start;                    
                    if(start){
                        $(this).text("Start");
                        clearInterval(inter);
                        $(".numbers").slideUp(1000, function(){ $(".numbers h1").html("");} );
                    }
                    else{ 
                        $(this).text("End");
                        minets=0;
                        date_start=GetDateTime();
                        $(".numbers").slideDown("slow");
                       inter=setInterval(function(){
                            minets++;
                            $(".numbers h1").html(Math.floor(minets/60)+":" + minets%60);
                        },600); 
                         
                         }
                });
                });
        </script>
    </head>
    <body>
        
            <h1>Здравствуйте,<?php echo e($Surname."  ".$Name); ?></h1>
        
        <div class="container">
              <button id="Work_button">Start</button>
            <div class="numbers">
            <h1>0:0</h1></div>
        </div>
        <?php $__env->stopSection(); ?>
