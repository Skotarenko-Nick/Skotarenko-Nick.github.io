<?php $__env->startSection('script'); ?>
        <script>
               $(document).ready(function(){
                   $("#Statictic").slideDown();
                 $(".container .btn").click(function(){
                    $(this).slideUp('slow');
                      var minets=0;
                        $(".Timer_form").slideDown("slow");
                    $("input[name='hours']").val(0);
                           $("input[name='minutes']").val(0);
                       setInterval(function(){
                            minets++;
                            $("input[name='hours']").val(Math.floor(minets/60));
                           $("input[name='minutes']").val(minets%60);
                        },60000);
                    });
                });
        </script>
    
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('inform'); ?>
              <div class="Statictic_table">
            <table id="Statictic">
            <?php include('date.php'); ?>
                <tr> 
                <th>День недели</th>
                <th>Число</th>
                <th>Пришел</th>
                <th>Ушел</th>
                <th>Провел на рабочем месте</th>
                </tr>
                <?php foreach($static as $row): ?>
                <tr>
            <td> <?php echo e($day[ @date('w', strtotime($row->Start))]); ?></td>
            <td>
              <?php echo e(@date("d", strtotime($row->Start))."  ".$month[@date("n", strtotime($row->Start))]." ".@date("Y", strtotime($row->Start))); ?>

              </td>
            <td><?php echo e(@date("G:i", strtotime($row->Start))); ?> </td>
            <td><?php echo e(@date("G:i", strtotime($row->Finish))); ?> </td>
            <td><?php if( @date("i", strtotime($row->Finish)) >= @date("i", strtotime($row->Finish)) ): ?> 
                    <?php echo e((@date("G", strtotime($row->Finish))- @date("G", strtotime($row->Start)))." час(ов) :"
                .(@date("i", strtotime($row->Finish)) - @date("i", strtotime($row->Start)))." минут(ы)"); ?>

                <?php else: ?>
                     <?php echo e((@date("G", strtotime($row->Finish))-1- @date("G", strtotime($row->Start)))." час(ов) :"
                .(60+@date("i", strtotime($row->Finish)) - @date("i", strtotime($row->Start)))." минут(ы)"); ?>

                <?php endif; ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
             </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cabinet', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>