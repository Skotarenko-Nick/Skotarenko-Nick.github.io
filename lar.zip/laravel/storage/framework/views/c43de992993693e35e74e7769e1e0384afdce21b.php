@layout('template')

<?php $__env->startSection('title'); ?>
  Домашняя страничка Дейла.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
  @parent
  <li><a href="#">Обо мне</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <h1>Привет!</h1>
  <p>Добро пожаловать на мою домашнюю страничку!</p>
<?php $__env->stopSection(); ?>