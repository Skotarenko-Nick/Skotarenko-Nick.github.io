 $(document).ready(function()
            {
                var show_add=true,show_table=true;
                var url= location.href;
                if( url.indexOf("page")>0){
                    $("#Statictic").slideToggle("slow");
                    $('.pagination').slideToggle("slow");
                    show_table=!show_table;
                    $(".Statictic_table .btn a").text("Скрыть");
                }
                $(".container .btn").click(function(){
                    $(this).slideUp('slow');
                      var minets=0;
                        $(".Timer_form").slideDown("slow");
                    $("input[name='hours']").val(0);
                           $("input[name='minutes']").val(0);
                       setInterval(function(){
                            minets++;
                            $("input[name='hours']").val(Math.floor(minets/60));
                           $("input[name='minutes']").val(minets%60);
                        },60000);
                 
                    });
                
                $(".add .btn").click(function(){
                    $(".add_form").slideToggle();
                    show_add=!show_add;
                    if(!show_add) $(".add .btn a").text("Скрыть");
                    else  $(".add .btn a").text("Добавить сотрудника");
                   
                });
                $(".Statictic_table .btn").click(function(){
                    $("#Statictic").slideToggle("slow");
                    $('.pagination').slideToggle("slow");
                    show_table=!show_table;
                    if(!show_table) $(".Statictic_table .btn a").text("Скрыть");
                    else $(".Statictic_table .btn a").text("Показать статистику");
                       
                         
                });
            });