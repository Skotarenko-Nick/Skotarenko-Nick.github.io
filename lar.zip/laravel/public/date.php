    <?php 

            $month[1]  = "Января"; 
            $month[2]  = "Февраля"; 
            $month[3]  = "Марта"; 
            $month[4]  = "Апреля"; 
            $month[5]  = "Мая"; 
            $month[6]  = "Июня"; 
            $month[7]  = "Июля"; 
            $month[8]  = "Августа"; 
            $month[9]  = "Сентября"; 
            $month[10] = "Октября"; 
            $month[11] = "Ноября"; 
            $month[12] = "Декабря"; 

            $day[0] = "Воскресенье"; 
            $day[1] = "Понедельник"; 
            $day[2] = "Вторник"; 
            $day[3] = "Среда"; 
            $day[4] = "Четверг"; 
            $day[5] = "Пятница"; 
            $day[6] = "Суббота"; 

            $dnum = date("w"); 
            $mnum = date("n"); 
            $daym = date("d"); 
            $year = date("Y"); 

            $textday = $day[$dnum]; 
            $monthm = $month[$mnum]; 

                ?>