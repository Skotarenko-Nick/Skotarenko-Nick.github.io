<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateHoursTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Hours', function (Blueprint $table) {
             $table->string('login',20);
            
            $table->dateTime("Start");
            $table->primary(['login','Start']);
            $table->dateTime("Finish");
            $table->foreign('login')->references('login')->on('employes');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('Hours');
    }
}
