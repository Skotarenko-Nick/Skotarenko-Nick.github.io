<html lang="ru-RU">
<head>
<meta charset="UTF-8">
<title>Личный кабинет</title>
<link rel="stylesheet" type="text/css" href="css/Personal.css">
<script src="js/jquery-2.1.4.min.js"></script>
@yield('script')
</head>
    <body>
            <h1>Здравствуйте,{{ "  ".$Surname."  ".$Name }}</h1>
        <div class="container">
               <div class="btn">
         <a href="#" >Старт</a>
        <div class="bg"></div>
            </div>
           <div class="Timer_form">
            {!! Form::open(['action' => ['HoursController@add', $login],'method' => 'post','class' => 'Timer']) !!}
                <input type="text"  name="hours"  readonly />
                <input type="text"  name="minutes" readonly /><br />
             {!!Form::submit('Всем пока') !!}
            {!! Form::close()!!}
            </div>
        </div>
@yield('inform')
    
   
    </body>
</html>