@extends('cabinet')
@section('script')
        <script>
               $(document).ready(function(){
                   $("#Statictic").slideDown();
                 $(".container .btn").click(function(){
                    $(this).slideUp('slow');
                      var minets=0;
                        $(".Timer_form").slideDown("slow");
                    $("input[name='hours']").val(0);
                           $("input[name='minutes']").val(0);
                       setInterval(function(){
                            minets++;
                            $("input[name='hours']").val(Math.floor(minets/60));
                           $("input[name='minutes']").val(minets%60);
                        },60000);
                    });
                });
        </script>
    
        @endsection
        @section('inform')
              <div class="Statictic_table">
            <table id="Statictic">
            <?php include('date.php'); ?>
                <tr> 
                <th>День недели</th>
                <th>Число</th>
                <th>Пришел</th>
                <th>Ушел</th>
                <th>Провел на рабочем месте</th>
                </tr>
                @foreach($static as $row)
                <tr>
            <td> {{ $day[ @date('w', strtotime($row->Start))] }}</td>
            <td>
              {{  @date("d", strtotime($row->Start))."  ".$month[@date("n", strtotime($row->Start))]." ".@date("Y", strtotime($row->Start)) }}
              </td>
            <td>{{@date("G:i", strtotime($row->Start))}} </td>
            <td>{{@date("G:i", strtotime($row->Finish))}} </td>
            <td>@if( @date("i", strtotime($row->Finish)) >= @date("i", strtotime($row->Finish)) ) 
                    {{(@date("G", strtotime($row->Finish))- @date("G", strtotime($row->Start)))." час(ов) :"
                .(@date("i", strtotime($row->Finish)) - @date("i", strtotime($row->Start)))." минут(ы)" }}
                @else
                     {{(@date("G", strtotime($row->Finish))-1- @date("G", strtotime($row->Start)))." час(ов) :"
                .(60+@date("i", strtotime($row->Finish)) - @date("i", strtotime($row->Start)))." минут(ы)" }}
                @endif</td>
                    </tr>
                @endforeach
            </table>
             </div>
@endsection