<!DOCTYPE HTML>
<html lang="ru-RU">
    <head>
    <meta charset="UTF-8">
    <title>Авторизация</title>
        <style>
            body{
                text-align: center;
                font-size: 24px;
                background: #000;
                color:white;
            }
            .container{
                width: 30%;
                margin-left: 35%;
                margin-top: 20%;
                border: 1px solid white;
            }
           
           input{
                font-size:20px;
               margin: 5px;
            }
            input[type='submit']
            {
                background: rgba(222,222,222,1);
                background: linear-gradient(to right, rgba(222,222,222,1) 0%, rgba(204,204,204,1) 51%, rgba(214,214,214,1) 76%, rgba(250,250,250,1) 100%) repeat scroll 0 0 transparent;
                border: 1px solid #394D63;
                border-radius: 0.5em 0.5em 0.5em 0.5em;
                box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
                color: #000;
                cursor: pointer;
                display: inline-block;
                font: 14px/100% Arial,Helvetica,sans-serif;
                margin: 10px 2px;
                outline: medium none;
                padding: 0.5em 2em 0.55em;
                text-align: center;
                text-decoration: none;
                text-shadow: 0 1px 1px rgba(0, 0, 0, 0.3);
                vertical-align: baseline;
                
            }
             input[type='submit']:hover 
            {
                background: linear-gradient(center top , #718DA8, #48627D) repeat scroll 0 0 transparent;
                text-decoration: none;
                
            }
            
            h4{
                margin: 5px;
            }
        </style>
    </head>
    <body>
        @if (isset( $error))
            <h1>Неверный ввод логина или пароля</h1>
        @endif
        <div class="container">
            <h4> Авторизация</h4>
            {!! Form::open(['action' => ['LoginController@check'],'method' => 'post']) !!}
                <label for="Login"> Логин: </label>
                <input type="text"  name="login" placeholder="Введите ваш логин" /> <br />
                <label for="Pass"> Пароль:</label>
                <input type="password"  name="pass" placeholder="Введите ваш пароль" /><br />
                
            {!! Form::submit('Войти') !!}
            {!! Form::close()!!}
        </div>
    </body>
</html>