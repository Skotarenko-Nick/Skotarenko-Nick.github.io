<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|

*/
Route::get('/',"LoginController@index");
Route::get('/check',array('as' => 'logined', 'uses' => "LoginController@check"));
Route::post('/check',array('as' => 'logined', 'uses' => "LoginController@check"));
Route::post('/add={login}',array('as' => 'add_user', 'uses' => "AddControl@add"));
Route::get('/add={login}',array('as' => 'add_user', 'uses' => "AddControl@add"));
Route::get('/login={log}',array( 'as' => 'add', 'uses' =>"HoursController@add"))->where(["log" => '[a-zA-Z\d]+']);
Route::post('/login={log}',"HoursController@add")->where(["log" => '[a-zA-Z\d]+']);