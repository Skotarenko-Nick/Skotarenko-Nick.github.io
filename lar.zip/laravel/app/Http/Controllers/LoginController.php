<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Employe;
use App\Hour;
use DB;

class LoginController extends Controller
{
    public function index()
    {
        return view("login");    
    }
    public function check()
    {
        $log=$_REQUEST['login'];
        $pass=md5("<^_^>".$_REQUEST['pass']."<^_^>");
        $user=Employe::find($log);
        if($user && $user['pass']==$pass){
         $date=getdate();
            $CurentDate=$date['year']."-".$date['mon']."-".($date['mday']-$date['wday'])." 00:00:01"; 
            $static=Hour::whereRaw("login=? and DATE_FORMAT(Start,'%w') between 0 and 6 and Start>?",[$log,$CurentDate])->get();
            if($user['is_admin']==false){ 
                $person=[
                "Name" => $user->Name,
                "Surname"  => $user->Surname,
                "login" => $user->login,
                "static" => $static
                ];
                return view("personal",$person);
            }
            else{
                $FirstDay=$date['year']."-".$date['mon']."-01 00:00:01"; 
                $users = DB::table('employes')
            ->join('Hours', 'employes.login', '=', 'Hours.login')
            ->select('employes.login','Name', 'Surname', 'Start','Finish')
            ->where('Start','>',$FirstDay)->paginate(10);
                $inforamtion=[
                    "Name" => $user->Name,
                    "Surname"  => $user->Surname,
                    "login" => $user->login,
                    "pass" => $pass,
                    "users" => $users
                ];
                
                return view("admin",$inforamtion);
                }
        }
        else 
            return view("login",['error' => 'True']);
    }
    
}
