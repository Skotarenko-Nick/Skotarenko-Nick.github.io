<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Hour;
class HoursController extends Controller
{
    public function add($login)
    {
        $hours=$_REQUEST['hours'];
        $minets=$_REQUEST['minutes'];
        $date=getdate();
        if($date['minutes']>=$minets)
            $start=$date['year']."-".$date['mon']."-".$date['mday']." ".($date['hours']-$hours).":".($date['minutes']-$minets).':00';
        else $start=$date['year']."-".$date['mon']."-".$date['mday']." ".($date['hours']-$hours-1).":".(60+$date['minutes']-$minets).':00';
        if(Hour::where('login',$login)->where('Start',$start)->count()==0)
        {
            $row=new Hour;
            $row->login=$login;
            $CurentDate=$date['year']."-".$date['mon']."-".$date['mday']." ".$date['hours'].":".$date['minutes'].':00';
            $row->Start=$start;
            $row->Finish=$CurentDate; 
            $row->save();
        }
        return view("login");
    }
}
