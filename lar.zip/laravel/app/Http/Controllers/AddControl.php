<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Employe;
use DB;
class AddControl extends Controller
{
    public function add($login)
    {
        if(!Employe::find($_REQUEST['login']))
        {
            $row=new Employe;
            if(preg_match("/^[a-zA-z\d]+$/" , $_REQUEST['login']) && preg_match("/^[a-zA-z\d]+$/" , $_REQUEST['pass']) && 
               preg_match("/^[a-zA-zа-яА-Я]+$/" , $_REQUEST['Name']) && preg_match("/^[a-zA-zа-яА-Я]+$/" , $_REQUEST['Surname']))
            {  
               $row->login=$_REQUEST['login'];
                $row->pass=md5("<^_^>".$_REQUEST['pass']."<^_^>");
                $row->Name=$_REQUEST['Name'];
                $row->Surname=$_REQUEST['Surname'];
                $row->is_admin=isset($_REQUEST['admin']) ? 1 : 0;
                $complete=$row->save();
                }
            else $complete=false;
        }
        else $complete=false;
        $admin=Employe::find($login);
        $date=getdate();
        $FirstDay=$date['year']."-".$date['mon']."-01 00:00:01"; 
        $users = DB::table('employes')
            ->join('Hours', 'employes.login', '=', 'Hours.login')
            ->select('employes.login','Name', 'Surname', 'Start','Finish')
            ->where('Start','>',$FirstDay)->paginate(10);
                $inforamtion=
                [
                    "Name" => $admin->Name,
                    "Surname"  => $admin->Surname,
                    "login" => $admin->login,
                    "pass" => $admin->pass,
                    "users" => $users,
                    "add"=> $complete,
                ];
                
            return view("admin",$inforamtion);
                
    }
    
}
